# Tóm tắt thực nghiệm HOG (tự sinh)

- Dữ liệu: dev 1,672 ảnh / 418 quả {'Unripe': 352, 'Half_Ripe': 408, 'Ripe': 524, 'Overripe': 388}; test 288 ảnh / 72 quả {'Unripe': 56, 'Half_Ripe': 80, 'Ripe': 92, 'Overripe': 60}; ngoài 4,273 ảnh ({'BananaRipeness_GitHub': 3462, 'BananaImageBD': 811})
- Split: CHIA LẠI theo quả; split có sẵn của bước tiền xử lý có 347 quả nằm ở >1 split (100.0% ảnh test có cùng quả trong train/val) (trên split cũ cùng cấu hình cho accuracy 0.735 / macro-F1 0.740 so với 0.785 / 0.791 khi chia theo quả: chênh -0.051 macro-F1; rò rỉ làm tăng điểm nhưng với HOG ở đây ảnh hưởng nhỏ)
- Cấu hình tốt nhất theo CV (dev): **('hog_rgb_concat', 16, 'SVM-RBF')** – macro-F1 0.696 ± 0.036, accuracy 0.698 ± 0.033, macro-precision 0.699, macro-recall 0.698
- Tập test cùng miền (test_BananaID, huấn luyện lại trên toàn dev): accuracy 0.785, macro-precision 0.790, macro-recall 0.793, macro-F1 0.791, lệch ≤1 mức 0.962
- Tham số chọn (toàn dev): {'C': 10, 'gamma_mult': 1}; độ nhạy tham số (max-min macro-F1 CV trong): 0.490
- So sánh biến thể HOG (macro-F1 CV tốt nhất của mỗi biến thể): hog_gray 0.673, hog_rgb_concat 0.696, hog_rgb_maxgrad 0.631
- So sánh bộ phân loại (tốt nhất của mỗi loại): KNN 0.506, SVM-linear 0.688, SVM-RBF 0.696
- Lệch ≤ 1 mức (CV): 0.925; ảnh nhầm 505/1672, trong đó nhầm sang lớp kề 75.0%
- Cặp nhầm nhiều nhất: Ripe→Half_Ripe (76), Half_Ripe→Unripe (71), Half_Ripe→Ripe (71)
- Accuracy CV theo giống: {'Ambon': 0.574, 'Cavendish': 0.802, 'Mas': 0.785, 'Raja': 0.747, 'Saba': 0.587}; theo góc chụp: {'Bottom': 0.696, 'Left': 0.722, 'Right': 0.679, 'Top': 0.694}
- Đường cong học: macro-F1 0.492 (n=65 quả) → 0.699 (n=329 quả); tăng +0.024 ở bước cuối (còn tăng – thêm dữ liệu có thể giúp)
- Silhouette: theo lớp {'hog_gray': -0.009, 'hog_rgb_concat': -0.009, 'hog_rgb_maxgrad': -0.011} so với theo giống {'hog_gray': 0.015, 'hog_rgb_concat': 0.014, 'hog_rgb_maxgrad': 0.011} (nếu theo giống cao hơn hẳn: đặc trưng HOG phản ánh hình dạng/giống nhiều hơn độ chín)
- Kiểm định ngoài ext_BananaImageBD (cùng cấu hình hog_rgb_concat/SVM-RBF): accuracy 0.297, macro-F1 0.223 so với CV 0.696 (chênh +0.473); phân bố dự đoán [513, 91, 190, 17] so với thật [211, 203, 195, 202]
  - **Cảnh báo:** ext_BananaImageBD thấp hơn CV rất nhiều → lệch miền (thiết bị/nền/ánh sáng/định nghĩa nhãn) hoặc mô hình dựa vào đặc điểm riêng của ['BananaID']; nêu trong phần hạn chế.
- Kiểm định ngoài ext_BananaRipeness_GitHub (cùng cấu hình hog_rgb_concat/SVM-RBF): accuracy 0.256, macro-F1 0.193 so với CV 0.696 (chênh +0.503); phân bố dự đoán [1359, 188, 1862, 53] so với thật [1421, 811, 545, 685]
  - **Cảnh báo:** ext_BananaRipeness_GitHub thấp hơn CV rất nhiều → lệch miền (thiết bị/nền/ánh sáng/định nghĩa nhãn) hoặc mô hình dựa vào đặc điểm riêng của ['BananaID']; nêu trong phần hạn chế.
- Lệch miền (độ giống cosine gần nhất tới dev): {'dev -> dev (quả khác)': 0.925000011920929, 'test_BananaID -> dev': 0.9279999732971191, 'ext_BananaImageBD -> dev': 0.6449999809265137, 'ext_BananaRipeness_GitHub -> dev': 0.6010000109672546}

Lưu ý: ánh xạ nhãn giữa các dataset chỉ xấp xỉ.